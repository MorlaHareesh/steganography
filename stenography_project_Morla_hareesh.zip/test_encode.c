#include <stdio.h>
#include "encode.h"
#include "types.h"

int main(int argc, char **argv)
{
		if (argc > 1 && argc < 8)
		{
				if ((check_operation_type(argv)) == e_encode)
				{
						EncodeInfo encInfo;
						
						if (read_and_validate_encode_args(argc, argv, &encInfo) == e_success)
						{
							if (do_encoding(&encInfo) == e_failure)
							{
								fprintf(stderr,"Error: %s function failed\n","do_encoding()");
								return 1;
							}
							fclose(encInfo.fptr_src_image);
							fclose(encInfo.fptr_secret);
							fclose(encInfo.fptr_stego_image);
							printf("Encoding Done Successfully\n");
						}
						else
						{
								fprintf(stderr, "Error: %s function failed\n", "read_and_validation_encode_args()");
								return 1;
						}
				}
				else
				{
					fprintf(stderr,"Error: Invalid option\n");
					printf("./lsb_steg: Encoding: ./lsb_steg -e <.bmp file> <.txt file> [Output file]\n./lsb_steg: Deconding: ./lsb_steg -d <.bmp file> [output file]\n");
					return 1;
				}
		}
		else
		{
			printf("./lsb_steg: Encoding: ./lsb_steg -e <.bmp file> <.txt file> [Output file]\n./lsb_steg: Deconding: ./lsb_steg -d <.bmp file> [output file]\n");
			return 1;
		}
		return 0;
}

